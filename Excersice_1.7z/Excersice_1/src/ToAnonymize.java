import java.util.ArrayList;

public class ToAnonymize {

    private String fname = "C:\\Users\\ngerontsos\\Desktop\\dataset.txt";
    private String fname2 = "C:\\Users\\ngerontsos\\Desktop\\config.txt";
    private String[][] dataset = new String[3][4];
    private String[][] dataToEncrypt;
    private ArrayList<String> columnNames;
    private int rows_count;
    Reader r1 = new Reader(fname);
    Reader r2 = new Reader(fname2,0);


    public ToAnonymize(){

        dataset = r1.giveMeData();
        columnNames = r2.getOnlyCols();

        int col = 0;
        String search = "";

        //this.dataToEncrypt = new String[dataset.length][columnNames.size()];
        this.dataToEncrypt = new String[2][4];

        for(int i=0; i<columnNames.size(); i++)
        {
            int row = 0;
            search = columnNames.get(i);
            for(int j=0; j<4;j++)
            {
                if (dataset[0][j].equals(search) )
                {
                    for(int x=1;x<dataset.length;x++)
                    {
                        dataToEncrypt[row][col] = dataset[x][j];
                        row++;
                    }
                    col++;
                }
            }
//            for(int j=1; j<dataset[i].length -1; j++)
//            {
//
//                dataToEncrypt[row][col] = dataset[j][columnNames.indexOf(search)];
//                row++;
//            }

            this.rows_count = row;
        }



    }



    public String[][] arrToAnon()
    {
        return dataToEncrypt;
    }

    public int getNumOfCols()
    {
        return columnNames.size();
    }

    public int getRows()
    {
        return rows_count;
    }


}
