import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ToAnonymize t1 = new ToAnonymize();
        Scanner scanner = new Scanner(System.in);
        //System.out.println("Give the file to be created: ");
        //String name = scanner.nextLine();
        String[][] array;

        array = t1.arrToAnon();

       // array = new String[t1.getRows()][t1.getNumOfCols()];


        for(int i=0; i< t1.getRows(); i++)
        {
            for(int j=0; j< t1.getNumOfCols(); j++)
            {
                String encryptedString
                        = AES.encrypt(array[i][j]);
                System.out.println("----------------");
                System.out.println(array[i][j]);
                System.out.println(encryptedString);

            }
        }




    }
}