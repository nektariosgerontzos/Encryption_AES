import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Reader {

    private String fname, fname2;
    private String[][] alldata = new String[3][4];
    private ArrayList<String> onlyCols = new ArrayList<>();
    private int rows=0;


    public Reader(String fname)
    {
        this.fname= fname;

        try{
            File obj = new File(this.fname);
            Scanner reader = new Scanner(obj);
        while( reader.hasNextLine()){
            String data = reader.nextLine(); //fetches the first line
            String arr[] = data.split("\t"); //assigns the arr table with each data value after the split
            for(int i =0; i< arr.length;i++)
            {
                alldata[rows][i] = arr[i];
                //System.out.println(alldata[rows][i]);
            }
            rows++;

        }
        reader.close();
        }catch (FileNotFoundException e) {
            System.out.println("An error has occured.");
            e.printStackTrace();
        }


    }

    public Reader(String fname , int rows)
    {
        this.fname2= fname;

        this.rows=rows;

        try{
            File obj = new File(fname2);
            Scanner reader = new Scanner(obj);
            while( reader.hasNextLine()) {
                String data = reader.nextLine();
                onlyCols.add(data);
                //System.out.println(onlyCols); //swsto
            }
            reader.close();
        }catch ( FileNotFoundException e)
        {
            System.out.println("An error has occured.");
            e.printStackTrace();
        }
    }

    public String[][] giveMeData()
    {
        return alldata;
    }

    public ArrayList<String> getOnlyCols()
    {
        return onlyCols;
    }


}
